export default [
  require('/Users/kakao/Playground/docdo/node_modules/infima/dist/css/default/default.css'),
  require('/Users/kakao/Playground/docdo/node_modules/@docusaurus/theme-classic/lib/prism-include-languages'),
  require('/Users/kakao/Playground/docdo/node_modules/@docusaurus/theme-classic/lib/nprogress'),
  require('/Users/kakao/Playground/docdo/src/css/custom.css'),
];
